function abrirModal() {
  document.getElementById("modalPassword").style.display = "flex";
}
function cerrarModal() {
  document.getElementById("modalPassword").style.display = "none";
}