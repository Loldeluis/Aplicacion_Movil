<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../../View/login.php');
    exit;
}
?>
<form action="../../Controller/Usuario/PerfilController.php" method="post">
  <input type="hidden" name="accion" value="eliminar">
  <input type="hidden" name="id_usuario" value="<?= $_SESSION['usuario_id'] ?>">

  <label>Confirma tu contraseña:</label>
  <input type="password" name="password" required>

  <button type="submit">Eliminar definitivamente</button>

  <?php if (isset($_GET['error'])): ?>
    <p style="color: red;">Contraseña incorrecta.</p>
  <?php endif; ?>
</form>