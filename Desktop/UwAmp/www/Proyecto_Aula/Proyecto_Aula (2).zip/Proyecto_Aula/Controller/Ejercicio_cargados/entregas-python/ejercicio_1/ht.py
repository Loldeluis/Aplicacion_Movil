#!/usr/bin/env python3
# ejercicio_1.py
# Descripción: Escribe un programa que imprima 'Hola Mundo'.

print("Hola Mundo")
