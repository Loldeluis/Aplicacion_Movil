<?php


require_once __DIR__ . '/../../Model/Docente/EntregaModel.php';
$model = new EntregaModel();
include __DIR__ . '/../../View/Panel_docente/calificaciones.php';
