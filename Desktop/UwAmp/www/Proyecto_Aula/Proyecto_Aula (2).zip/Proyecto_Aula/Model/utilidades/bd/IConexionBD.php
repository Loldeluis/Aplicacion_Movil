<?php
// Proyecto_Aula/Model/utilidades/bd/IConexionBD.php

interface IConexionBD {
    public function conectar();
    public function desconectar();
}
